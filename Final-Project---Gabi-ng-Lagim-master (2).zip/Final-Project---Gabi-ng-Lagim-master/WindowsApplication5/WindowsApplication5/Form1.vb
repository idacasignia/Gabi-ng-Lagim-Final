﻿Imports System.IO
Imports System.Net.Sockets

Public Class Form1

    Dim client As TcpClient
    Dim sWriter As StreamWriter
    Dim NIckFrefix As String = "Player 2"
    Sub xLoad() Handles Me.Load
        Me.Text &= " " & NIckFrefix
    End Sub
    Delegate Sub _xUpdate(ByVal str As String)
    Sub xUpdate(ByVal str As String)
        If InvokeRequired Then
            Invoke(New _xUpdate(AddressOf xUpdate), str)
        Else
            TextBox3.AppendText(str & vbNewLine)
        End If
    End Sub

    Sub read(ByVal ar As IAsyncResult)
        Try
            xUpdate(New StreamReader(client.GetStream).ReadLine)
            client.GetStream.BeginRead(New Byte() {0}, 0, 0, AddressOf read, Nothing)

        Catch ex As Exception
            xUpdate("You have disconnected from server")
            Exit Sub
        End Try
    End Sub
    Private Sub send(ByVal str As String)
        Try
            sWriter = New StreamWriter(client.GetStream)
            sWriter.WriteLine(str)
            sWriter.Flush()
        Catch ex As Exception
            xUpdate("You're not server")
        End Try
    End Sub
    Private Sub Connect_Click(sender As Object, e As EventArgs) Handles Connect.Click
        If Connect.Text = "Connect" Then
            Try
                client = New TcpClient(TextBox1.Text, CInt(TextBox2.Text))
                client.GetStream.BeginRead(New Byte() {0}, 0, 0, New AsyncCallback(AddressOf read), Nothing)
                Connect.Text = "Disconnect"
            Catch ex As Exception
                xUpdate("Can't connect to the server!")
            End Try
        Else
            client.Client.Close()
            client = Nothing
            Connect.Text = "Connect"
        End If
    End Sub
    Private Sub TextBox4_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox4.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            send(NIckFrefix & ": " & TextBox4.Text)
            TextBox4.Clear()
        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        send(NIckFrefix & ": " & TextBox4.Text)
        TextBox4.Clear()
    End Sub


    Private Sub TimerStart_Click(sender As Object, e As EventArgs)
        Timer1.Enabled = True
        Timer1.Start()
        Timer1.Interval = 1000
    End Sub

    Dim time As Integer = 15
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If time = 0 Then
            Timer1.Stop()
        Else
            time = time - 1
            TimeLabelBox.Text = time
        End If
    End Sub

End Class


